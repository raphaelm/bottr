<?php
if($self->connected){
	$self->disconnect();
}
?>