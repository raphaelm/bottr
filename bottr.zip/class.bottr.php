<?php
class bottr {
	public $server = 'jabber.org';
	public $port = 5222;
	public $username = '';
	public $password = '';
	public $resource = 'bottr';

	public $timeout = 5;

	public $version = '1.0.0';

	private $socket;
	private $connected = false;
	private $auth_id = '';

	public function __destruct(){
		if($this->connected){
			$this->disconnect();
		}
	}

	public function terminate(){
		if($this->connected){
			$this->disconnect();
		}
		exit;
	}

	public function connect($server = false, $port = false){
		if($server == false) $server = $this->server;
		if($port == false) $port = $this->port;
		$this->server = $server;
		$this->port = $port;

		if (function_exists("dns_get_record"))
		{
			$record = dns_get_record("_xmpp-client._tcp.$server", DNS_SRV);
			if (!empty($record))
			{
				$server = $record[0]["target"];
				$port = $record[0]["port"];
			}
		}

		$this->socket = fsockopen($server, $port, $errno, $errstr, 5);

		socket_set_blocking($this->socket, 0);
		stream_set_blocking($this->socket, false);
		socket_set_timeout($this->socket, 31536000);

		if(!$this->socket){
			return false;
		}
		$this->connected = true;
		$this->sendXML("<?xml version='1.0' encoding='UTF-8' ?" . "><stream:stream to='{$this->server}' xmlns='jabber:client' xmlns:stream='http://etherx.jabber.org/streams'>\n");
	}

	public function auth($username = false, $password = false, $resource = false){
		if(!$this->connected){
			trigger_error('Not connected');
			return false;
		}
		if($username == false) $username = $this->username;
		if($password == false) $password = $this->password;
		if($resource == false) $resource = $this->resource;
		$this->username = $username;
		$this->password = $password;
		$this->resource = $resource;

		$this->auth_id	= "auth_" . md5(time() . microtime());
		$this->sendXML("<iq type='set' id='{$this->auth_id}'><query xmlns='jabber:iq:auth'><username>".htmlspecialchars($username)."</username><resource>".htmlspecialchars($resource)."</resource><password>".htmlspecialchars($password)."</password></query></iq>\n");
	}

	public function disconnect(){
		if($this->connected){
			fclose($this->socket);
		}
		$this->connected = false;
	}

	public function sendMessage($to, $body){
		if(!$this->connected){
			trigger_error('Not connected');
			return false;
		}
		$this->sendXML("<message id='{$this->auth_id}' type='chat' to='$to'><body>".htmlspecialchars($body)."</body></message>", false);
	}

	public function enterLoop(){
		while(true){
			$contents = "";
			while($contents == ""){
				$contents .= fgets($this->socket);
			}
			echo "Rec: ".$contents."\n";
		}
	}

	private function sendXML($xml, $expect_response = true, $debug = false){
		if(defined('DEBUG') OR $debug) echo "Send: $xml\n";
		if(!$this->connected){
			trigger_error('Not connected');
			return false;
		}
		fputs($this->socket, $xml);
		if($expect_response){
			$contents = "";
			while($contents == ""){
				$contents .= fgets($this->socket);
			}
			if(defined('DEBUG') OR $debug){
				echo "Get: $contents\n";
			}
			return $contents;
		}
	}

}